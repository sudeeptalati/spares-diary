  
<?php include('oow_menu.php'); ?>   
<h4>Add new Out of Warranty Product</h4>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>